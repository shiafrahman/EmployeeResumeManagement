﻿namespace ResumeManagementAPI.Models.DTOs
{
    public class Status
    {
        public int StatusCode { get; set; }
        public string? Message { get; set; }
    }
}
